#ifndef ASquadInterpolator_H_
#define ASquadInterpolator_H_

#include "AInterpolator.h"
#include "AQuaternion.h"

class AInterpolatorSquad : public AInterpolator<AQuaternion>
{
public:
    AInterpolatorSquad() : AInterpolator<AQuaternion>() {}
    virtual AInterpolationType getType() const { return CUBIC_SQUAD; }
    virtual bool hasControlPoints() const { return false; }

    AQuaternion interpolateSegment(const std::vector<AQuaternion>& keys, 
        int segment, double u) const;
};

#endif
