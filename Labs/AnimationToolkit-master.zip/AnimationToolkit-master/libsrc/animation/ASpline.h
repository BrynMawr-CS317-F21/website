#ifndef ASpline_H_
#define ASpline_H_

#include "AInterpolator.h"
#include "AInterpolatorLinear.h"
#include "AInterpolatorBernstein.h"
#include "AInterpolatorMatrix.h"
#include "AInterpolatorCasteljau.h"
#include "AInterpolatorHermite.h"
#include "AInterpolatorBSpline.h"
#include "AInterpolatorSquad.h"
#include "AInterpolatorSBezier.h"

#include <map>
#include <vector>

template <class T>
class ASpline
{
public:
    ASpline(double fps = 120.0);
    virtual ~ASpline();

    void setFramerate(double fps);
    double getFramerate() const;

    void setDeltaTime(double dt);
    double getDeltaTime() const;

    void setInterpolationType(AInterpolationType type);
    AInterpolationType getInterpolationType() const;
    AInterpolator<T>* getInterpolator() const;

    T getValue(double t, bool loop = true);

    void editKey(int keyID, const T& value); 
    void appendKey(const T& value);
    void deleteKey(int keyID);
    T getKey(int keyID);
    int getNumKeys() const;
    void clear();

    double getDuration() const;
    double getNormalizedDuration(double t) const; 
    int getKeyID(double t) const;
    // takes a time t and returns the percentage through the motion

protected:
    bool mDirty;
    double mDt;
    double mFps;
    AInterpolator<T>* mInterpolator;
    std::vector<T> mKeys;
};


template <class T>
ASpline<T>::ASpline(double fps) : 
    mDirty(true),
    mDt(1.0/fps),
    mFps(fps),
    mInterpolator(new AInterpolatorLinear<T>())
{
}

template <class T>
ASpline<T>::~ASpline()
{
    delete mInterpolator;
}

template <class T>
void ASpline<T>::setFramerate(double fps)
{
    mFps = fps;
    mDt = 1/fps;
}

template <class T>
double ASpline<T>::getFramerate() const
{
    return mFps;
}

template <class T>
void ASpline<T>::setDeltaTime(double dt)
{
    mDt = dt;
    mFps = 1/dt;
}

template <class T>
double ASpline<T>::getDeltaTime() const
{
    return mDt;
}


template <class T>
void ASpline<T>::setInterpolationType(AInterpolationType type)
{
    delete mInterpolator;
    switch (type)
    {
    case LINEAR: mInterpolator = new AInterpolatorLinear<T>(); break;
    case CUBIC_BERNSTEIN: mInterpolator = new AInterpolatorBernstein<T>(); break;
    case CUBIC_CASTELJAU: mInterpolator = new AInterpolatorCasteljau<T>(); break;
    case CUBIC_HERMITE: mInterpolator = new AInterpolatorHermite<T>(); break;
    case CUBIC_MATRIX: mInterpolator = new AInterpolatorMatrix<T>(); break;
    case CUBIC_BSPLINE: mInterpolator = new AInterpolatorBSpline<T>(); break;
    case CUBIC_SBEZIER:
    case CUBIC_SQUAD:
        std::cout << "Interpolation type incompatible with spline class type\n";
        break;
    };
    
    mDirty = true;
}

template <>
inline void ASpline<AQuaternion>::setInterpolationType(AInterpolationType type)
{
    delete mInterpolator;
    switch (type)
    {
    case LINEAR: mInterpolator = new AInterpolatorLinear<AQuaternion>(); break;
    case CUBIC_SBEZIER: mInterpolator = new AInterpolatorSBezier(); break;
    case CUBIC_SQUAD: mInterpolator = new AInterpolatorSquad(); break;
    case CUBIC_BERNSTEIN: 
    case CUBIC_CASTELJAU: 
    case CUBIC_HERMITE: 
    case CUBIC_MATRIX: 
    case CUBIC_BSPLINE: 
        std::cout << "Interpolation type incompatible with spline class type quaternion\n";
        break;
    };
    
    mDirty = true;
}

template <class T>
AInterpolator<T>* ASpline<T>::getInterpolator() const
{
    return mInterpolator;
}

template <class T>
AInterpolationType ASpline<T>::getInterpolationType() const
{
    return mInterpolator->getType();
}

template <class T>
void ASpline<T>::editKey(int keyID, const T& value)
{
    assert(keyID >= 0 && keyID < (int) mKeys.size());
    mKeys[keyID] = value;
    mDirty = true;
}

template <class T>
void ASpline<T>::appendKey(const T& value)
{
    mKeys.push_back(value);
    mDirty = true;
}

template <class T>
void ASpline<T>::deleteKey(int keyID)
{
    assert(keyID >= 0 && keyID < (int) mKeys.size());
    mKeys.erase(mKeys.begin() + keyID);
    mDirty = true;
}

template <class T>
T ASpline<T>::getKey(int keyID)
{
    assert(keyID >= 0 && keyID < (int) mKeys.size());
    return mKeys[keyID];
}

template <class T>
int ASpline<T>::getNumKeys() const
{
    return (int) mKeys.size();
}

template <class T>
void ASpline<T>::clear()
{
    mKeys.clear();
}

template <class T>
double ASpline<T>::getDuration() const 
{
    return (mKeys.size()-1) * mDt;
}

template <class T>
double ASpline<T>::getNormalizedDuration(double t) const 
{
    double frac = t / getDuration();
    return frac - floor(frac);
}

template <class T>
int ASpline<T>::getKeyID(double t) const
{
    if (mKeys.size() == 0) return 0;

    t = getNormalizedDuration(t) * getDuration();
    return mInterpolator->computeSegment(t, getDeltaTime());
}

template <class T>
T ASpline<T>::getValue(double t, bool loop)
{
    if (mKeys.size() == 0) return T();

    if (loop)
    {
        t = getNormalizedDuration(t) * getDuration();
        //if (t >= getDuration()) t = getNormalizedDuration(t) * getDuration();
        //else if (t < 0) t = getDuration() + t;
    }
    else
    {
        if (t >= getDuration()-A_EPSILON) return mKeys[mKeys.size()-1];
        else if (t < 0) return mKeys[0];
    }

    if (mInterpolator->hasControlPoints() && mDirty) 
    {
        ((AInterpolatorCubic<T>*) mInterpolator)->computeControlPoints(mKeys);
        mDirty = false;
    }

    return mInterpolator->interpolate(mKeys, t, mDt);
}

#endif
