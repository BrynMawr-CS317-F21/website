#include "AJoint.h"

void AJoint::fk()
{
}

