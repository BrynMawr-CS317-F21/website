#ifndef APose_H_
#define APose_H_

#include "AVector3.h"
#include "AQuaternion.h"
#include <vector>

class APose
{
public:
    APose();
    APose(const APose& p);
    APose& operator = (const APose& p);
    virtual ~APose();

    friend APose operator - (const APose& v);                
    friend APose operator + (const APose& a, const APose& b);
    friend APose operator - (const APose& a, const APose& b);
    friend APose operator * (const APose& a, double d);  
    friend APose operator * (double d, const APose& a);  
    friend APose operator / (const APose& a, double d); 
    friend bool operator == (const APose& a, const APose& b); 
    friend bool operator != (const APose& a, const APose& b); 
    friend std::istream& operator>>(std::istream& s, APose& v);
    friend std::ostream& operator<<(std::ostream& s, const APose& v);

public:
    AVector3 rootPos;
    std::vector<AQuaternion> jointRots;
};

#endif

