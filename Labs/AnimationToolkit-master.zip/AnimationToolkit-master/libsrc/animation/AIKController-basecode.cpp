#include "AIKController.h"
#include <cmath>

bool AIKController::solveIKTwoLink(ASkeleton& skeleton, 
    const AVector3& goalPos)
{
    // Assume that skeleton is a two link chain 
    // solve for rotations for the first and second joint 
    // such that the position of the last joint is at goalPos
    return true;
}

bool AIKController::solveIKAnalytic(ASkeleton& skeleton, 
    int jointid, const AVector3& goalPos)
{
	if (jointid == -1) return true;

    AJoint* ankle = skeleton.getByID(jointid);
    if (!ankle->getParent())
    {
        std::cout << "Warning: solveIKAnalytic() needs joint "
            "with parent and grandparent\n";
        return false;
    }

    AJoint* knee = ankle->getParent();
    if (!knee->getParent())
    {
        std::cout << "Warning: solveIKAnalytic() needs joint "
            "with parent and grandparent\n";
        return false;
    }

    return true;
}

bool AIKController::solveIKCCD(ASkeleton& skeleton, int jointid, 
    const AVector3& goalPos, int chainSize, int maxIters, float nudgeFactor)
{
    if (_selectedJoint != jointid || chainSize != (int) _chain.size())
    {
        computeJointChain(skeleton, jointid, chainSize);
    }

    // There are no joints in the IK chain for manipulation
    if (_chain.size() == 0) return true;
    return false;
}

