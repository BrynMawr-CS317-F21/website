#include "AMatrix3.h"
#include "AQuaternion.h"

AVector3 AMatrix3::toEulerAnglesXYZ() const
{
   return AVector3();
}

AVector3 AMatrix3::toEulerAnglesXZY() const
{
   return AVector3();
}

AVector3 AMatrix3::toEulerAnglesYXZ() const
{
   return AVector3();
}

AVector3 AMatrix3::toEulerAnglesYZX() const
{
   return AVector3();
}

AVector3 AMatrix3::toEulerAnglesZXY() const
{
   return AVector3();
}

AVector3 AMatrix3::toEulerAnglesZYX() const
{
   return AVector3();
}

void AMatrix3::fromEulerAnglesXYZ(const AVector3& angleRad)
{
   *this = Identity;
}

void AMatrix3::fromEulerAnglesXZY(const AVector3& angleRad)
{
   *this = Identity;
}

void AMatrix3::fromEulerAnglesYXZ(const AVector3& angleRad)
{
   *this = Identity;
}

void AMatrix3::fromEulerAnglesYZX(const AVector3& angleRad)
{
   *this = Identity;
}

void AMatrix3::fromEulerAnglesZXY(const AVector3& angleRad)
{
   *this = Identity;
}

void AMatrix3::fromEulerAnglesZYX(const AVector3& angleRad)
{
   *this = Identity;
}

void AMatrix3::toAxisAngle(AVector3& axis, double& angleRad) const
{
   // TODO
}

void AMatrix3::fromAxisAngle(const AVector3& axis, double angleRad)
{
   // TODO
   *this = Identity;
}

