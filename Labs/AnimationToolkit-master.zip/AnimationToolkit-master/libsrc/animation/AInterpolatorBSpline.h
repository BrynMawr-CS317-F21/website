#ifndef ABSplineInterpolator_H_
#define ABSplineInterpolator_H_

#include "AInterpolatorCubic.h"

template <class T>
class AInterpolatorBSpline : public AInterpolatorCubic<T>
{
public:
    AInterpolatorBSpline() : AInterpolatorCubic<T>() {}
    virtual AInterpolationType getType() const { return CUBIC_BSPLINE; }

    virtual T interpolateSegment(
        const std::vector<T>& keys, int segment, double u) const;

    virtual void computeControlPoints(const std::vector<T>& keys);

protected:
    std::vector<double> mKnots;
};

#endif

