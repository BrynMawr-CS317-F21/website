#include "ATransform.h"
#include "AMatrix3.h"

ATransform ATransform::inverse() const
{
    return ATransform();
}

AVector3 ATransform::transformPoint(const AVector3& pos) const
{
   return AVector3();
}

AVector3 ATransform::transformVector(const AVector3& dir) const
{
   return AVector3();
}

ATransform operator * (const ATransform& t1, const ATransform& t2)
{
    ATransform tmp;
    return tmp;
}

