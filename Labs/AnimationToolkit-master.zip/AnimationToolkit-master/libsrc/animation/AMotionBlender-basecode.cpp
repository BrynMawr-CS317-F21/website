#include "AMotionBlender.h"
#include <algorithm>

void AMotionBlender::append(AMotion& input, 
    int startKeyId, int endKeyId, AMotion& output)
{
}

void AMotionBlender::align(AMotion& motion1, AMotion& motion2, 
    int startKeyId, int endKeyId, int numBlendFrames)
{
}

void AMotionBlender::crossfade(AMotion& motion1, AMotion& motion2,
    int startKeyId, int endKeyId, int numBlendFrames, AMotion& blend)
{
}

void AMotionBlender::blend(AMotion& motion1, AMotion& motion2,
    int startKeyId, int endKeyId, int numBlendFrames, AMotion& blend)
{
    if (startKeyId >= motion1.getNumKeys())
    {
        std::cout << "Invalid start key for motion 1" << 
            startKeyId << std::endl;
        return;
    }

    if (endKeyId >= motion2.getNumKeys())
    {
        std::cout << "Invalid end key for motion 2" << 
            startKeyId << std::endl;
        return;
    }

    if (startKeyId + numBlendFrames > motion1.getNumKeys())
    {
        std::cout << "Not enough frames for blending\n";
        numBlendFrames = motion1.getNumKeys() - startKeyId;
    }

    if (endKeyId + numBlendFrames > motion2.getNumKeys())
    {
        std::cout << "Not enough frames for blending\n";
        numBlendFrames = motion2.getNumKeys() - endKeyId;
    }

    if (numBlendFrames <= 0) return;

    blend.clear();
    blend.setFramerate(motion1.getFramerate());

    // TODO
}
