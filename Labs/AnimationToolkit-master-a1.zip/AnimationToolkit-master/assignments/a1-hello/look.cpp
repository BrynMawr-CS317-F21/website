#include "AFramework.h"
#include "AGLObjects.h" // Helpers for drawing shapes

class Look : public AFramework
{
public:
   Look() : AFramework(AFramework::Orthographic) // calls base class ctor
   {
   }

   virtual void setup() 
   {
      _mouseX = getWidth() * 0.5;
      _mouseY = getHeight() * 0.5;
   }

   virtual void draw() //overrides draw
   {
      // Draw the target
      AVector3 target = AVector3(_mouseX, _mouseY, 0);
      ASetColor(AVector3(1,0,0));
      ADrawSphere(target, 5);
   }

   void mouseMove(int x, int y) 
   {
       _mouseX = x;
       _mouseY = getHeight() - y;
   }

private:
    int _mouseX;
    int _mouseY;
};

int main(int argc, char** argv)
{
   Look viewer;
   viewer.init(argc, argv);
   viewer.run();
   return 0;
}
