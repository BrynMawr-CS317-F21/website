#include "AFramework.h"
#include "AGLObjects.h" // Helpers for drawing shapes
#include <random>
#include <functional>

class Velocity : public AFramework
{
public:
   Velocity() : AFramework(AFramework::Orthographic) // calls base class ctor
   {
   }

   virtual void setup() 
   {
   }

   virtual void update() 
   {
   }

   virtual void draw() 
   {
   }
};

int main(int argc, char** argv)
{
   Velocity viewer;
   viewer.init(argc, argv);
   viewer.run();
   return 0;
}
