#include "AFramework.h"
#include "AGLObjects.h" // Helpers for drawing shapes

class Eyes : public AFramework
{
public:
   Eyes() : AFramework(AFramework::Orthographic) // calls base class ctor
   {
   }

   virtual void draw() //overrides draw
   {
   }
};

int main(int argc, char** argv)
{
   Eyes viewer;
   viewer.init(argc, argv);
   viewer.run();
   return 0;
}
