# Readme

## How many hours did you work on this assignment (outside of lab)

## What was the hardest part of this assignment?

## What was the easiest part of this assignment?

## Did you complete any extra credits?  If so, how do I run them and where is the video?

