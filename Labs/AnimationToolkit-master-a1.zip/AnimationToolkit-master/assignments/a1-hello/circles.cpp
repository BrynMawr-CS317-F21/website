#include "AFramework.h"
#include "AGLObjects.h" // Helpers for drawing shapes
#include <random>
#include <functional>

class Circles : public AFramework
{
public:
   Circles() : AFramework(AFramework::Orthographic) // calls base class ctor
   {
   }

   virtual void setup() //overrides init
   {
   }

   virtual void update() //overrides update
   {
   }

   virtual void draw() //overrides draw
   {
   }

};

int main(int argc, char** argv)
{
   Circles viewer;
   viewer.init(argc, argv);
   viewer.run();
   return 0;
}
