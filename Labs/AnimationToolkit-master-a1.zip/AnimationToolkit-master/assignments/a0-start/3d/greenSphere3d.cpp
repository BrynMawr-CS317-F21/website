#include "AFramework.h"
#include "AGLObjects.h" // Helpers for drawing shapes

class GreenSphere3D : public AFramework
{
public:
   GreenSphere3D() : 
      AFramework(AFramework::Perspective) // calls base class ctor
   {
   }

   virtual void draw() //overrides draw
   {
      // colors are RGB triplets in range [0,1]
      ASetMaterial(AVector3(0,1,0));

      // draw a sphere at position (0,0,0)
      double radius = 10; 
      ADrawSphere(AVector3(0,0,0), radius);
   }
};

int main(int argc, char** argv)
{
   GreenSphere3D viewer;
   viewer.init(argc, argv);
   viewer.run();
   return 0;
}
