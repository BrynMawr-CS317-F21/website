#include "AFramework.h"
#include "AGLObjects.h" // Helpers for drawing shapes

class GreenSphere2D : public AFramework
{
public:
   GreenSphere2D() : 
      AFramework(AFramework::Orthographic) // calls base class ctor
   {
   }

   virtual void draw() //overrides draw
   {
      // colors are RGB triplets in range [0,1]
      ASetColor(AVector3(0,1,0));

      // draw a sphere at center of screen
      double x = getWidth() * 0.5;
      double y = getHeight() * 0.5;
      double radius = 10; 
      ADrawSphere(AVector3(x,y,0), radius);
   }
};

int main(int argc, char** argv)
{
   GreenSphere2D viewer;
   viewer.init(argc, argv);
   viewer.run();
   return 0;
}
