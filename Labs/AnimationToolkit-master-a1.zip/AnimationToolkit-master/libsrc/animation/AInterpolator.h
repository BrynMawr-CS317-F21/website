#ifndef AInterpolator_H_
#define AInterpolator_H_

#include <string>
#include <vector>
#include <Eigen/Dense>
#include "AConstants.h"

enum AInterpolationType
{
    LINEAR,
    CUBIC_BERNSTEIN,
    CUBIC_CASTELJAU,
    CUBIC_HERMITE,
    CUBIC_MATRIX,
    CUBIC_BSPLINE,
    CUBIC_SBEZIER,
    CUBIC_SQUAD
};

template <class T>
class AInterpolator
{
public:
    virtual ~AInterpolator() {}

    virtual T interpolate(const std::vector<T>& keys, 
        double time, double dt) const;

    virtual bool hasControlPoints() const = 0;
    virtual AInterpolationType getType() const = 0;

    // Given keys, control points, current segment start index, and the time, 
    // compute an interpolated value
    // the time is the fraction between keys[segment] and keys[segment+1]
    // you can assume that segment+1 is a valid index
    virtual T interpolateSegment(
        const std::vector<T>& keys, int segment, double u) const = 0;

    double computeNormalizedTime(double time, double dt) const;
    int computeSegment(double time, double dt) const;

protected:
    AInterpolator() {}
};

template <class T>
inline double AInterpolator<T>::computeNormalizedTime(double time, double dt) const
{
    int rawi = (int)(time / dt); // assumes uniform spacing
    double normalizedTime = (time - rawi*dt)/dt;
    return normalizedTime;
}

template <class T>
inline int AInterpolator<T>::computeSegment(double time, double dt) const
{
    int rawi = (int)(time / dt); // assumes uniform spacing
    return rawi;
}


template <class T>
T AInterpolator<T>::interpolate(
    const std::vector<T>& keys, double time, double dt) const
{
    int segment = computeSegment(time, dt);
    assert(segment >= 0 && segment < (int) keys.size());

    double normalizedTime = computeNormalizedTime(time, dt);
    assert(normalizedTime >= 0 && normalizedTime <= 1.0);

    return interpolateSegment(keys, segment, normalizedTime);
}

#endif

