#ifndef ACubicInterpolator_H_
#define ACubicInterpolator_H_

#include "AInterpolator.h"

template <class T>
class AInterpolatorCubic : public AInterpolator<T>
{
public:
    virtual ~AInterpolatorCubic() {}
    virtual bool hasControlPoints() const { return true; }

    // Given an ordered list of keys, compute corresponding control points
    virtual void computeControlPoints(const std::vector<T>& keys);
    virtual void editControlPoint(int ID, const T& value);
    virtual int getNumControlPoints() const;
    virtual T getControlPoint(int ID) const;
    virtual void clearControlPoints();
    virtual void appendControlPoint(T pt);

protected:
    AInterpolatorCubic() : AInterpolator<T>() {}
    std::vector<T> mCtrlPoints;
};

template <class T>
void AInterpolatorCubic<T>::editControlPoint(int ID, const T& value)
{
    assert(ID >= 0 && ID < (int) mCtrlPoints.size());
    mCtrlPoints[ID] = value;
}

template <class T>
T AInterpolatorCubic<T>::getControlPoint(int ID) const
{
    assert(ID >= 0 && ID < (int) mCtrlPoints.size());
    return mCtrlPoints[ID];
}

template <class T>
void AInterpolatorCubic<T>::clearControlPoints()
{
    mCtrlPoints.clear();
}

template <class T>
void AInterpolatorCubic<T>::appendControlPoint(T pt)
{
    mCtrlPoints.push_back(pt);
}

template <class T>
int AInterpolatorCubic<T>::getNumControlPoints() const
{
    return mCtrlPoints.size();
}

#endif

