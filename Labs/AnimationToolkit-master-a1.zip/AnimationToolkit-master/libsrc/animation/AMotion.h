#ifndef AMOTION_H_
#define AMOTION_H_

#include <map>
#include <string>
#include <fstream>
#include "AInterpolatorLinear.h"
#include "ASkeleton.h"
#include "ASpline.h"
#include "APose.h"

class AMotion : public ASpline<APose>
{
public:
    AMotion();
    virtual ~AMotion();

    void setInterpolationType(AInterpolationType type);
    void update(ASkeleton& skeleton, double time, bool loop = true);
};

inline AMotion::AMotion() : ASpline::ASpline<APose>() 
{
    setInterpolationType(AInterpolationType::LINEAR);
}

inline AMotion::~AMotion() 
{
}

inline void AMotion::setInterpolationType(AInterpolationType type)
{
    delete mInterpolator;
    switch (type)
    {
    case LINEAR: mInterpolator = new AInterpolatorLinear<APose>(); break;
    case CUBIC_SBEZIER: 
    case CUBIC_SQUAD: 
    case CUBIC_BERNSTEIN:
    case CUBIC_CASTELJAU:
    case CUBIC_HERMITE:
    case CUBIC_MATRIX:
    case CUBIC_BSPLINE:
        std::cout << "Interpolation type incompatible with "
            "spline class type quaternion\n";
        break;
    }
}

template <>
inline APose AInterpolatorLinear<APose>::interpolateSegment(
    const std::vector<APose>& keys, int segment, double u) const
{
    const APose& key1 = keys[segment];
    const APose& key2 = keys[segment+1];

    APose pose;
    pose.rootPos = key1.rootPos * (1-u) + key2.rootPos * u;
    for (int i = 0; i < (int) key1.jointRots.size(); i++)
    {
        AQuaternion q1 = key1.jointRots[i];
        AQuaternion q2 = key2.jointRots[i];
        AQuaternion q = AQuaternion::Slerp(q1, q2, u);
        pose.jointRots.push_back(q);
    }
    return pose;
}

inline void AMotion::update(ASkeleton& skeleton, double time, bool loop)
{
    APose pose = getValue(time, loop); 
    for (int i = 0; i < skeleton.getNumJoints(); i++)
    {
        AJoint* joint = skeleton.getByID(i);
        if (i==0) joint->setLocalTranslation(pose.rootPos);
        joint->setLocalRotation(pose.jointRots[i]);
    }
    skeleton.fk();
}


#endif
