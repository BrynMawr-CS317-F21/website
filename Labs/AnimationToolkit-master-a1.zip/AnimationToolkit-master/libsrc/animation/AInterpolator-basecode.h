#ifndef AInterpolatorBasecode_H_
#define AInterpolatorBasecode_H_

#include <string>
#include <vector>
#include <Eigen/Dense>
#include "AInterpolator.h"
#include "AInterpolatorCubic.h"
#include "AInterpolatorBSpline.h"
#include "AInterpolatorBernstein.h"
#include "AInterpolatorCasteljau.h"
#include "AInterpolatorHermite.h"
#include "AInterpolatorLinear.h"
#include "AInterpolatorMatrix.h"
#include "AInterpolatorSBezier.h"
#include "AInterpolatorSquad.h"

//---------------------------------------

template <class T>
T AInterpolatorBSpline<T>::interpolateSegment(
    const std::vector<T>& keys,
    int segment, double t) const
{
    T xyz;
    return xyz;
}

template <class T>
void AInterpolatorBSpline<T>::computeControlPoints(
    const std::vector<T>& keys)
{
    AInterpolatorCubic<T>::clearControlPoints();
}


template <class T>
T AInterpolatorBernstein<T>::interpolateSegment(
    const std::vector<T>& keys,
    int segment, double t) const
{
    //T b0 = AInterpolatorCubic<T>::getControlPoint(segment * 4);
    //T b1 = AInterpolatorCubic<T>::getControlPoint(segment * 4 + 1);
    //T b2 = AInterpolatorCubic<T>::getControlPoint(segment * 4 + 2);
    //T b3 = AInterpolatorCubic<T>::getControlPoint(segment * 4 + 3);

    T xyz;
    return xyz;
}

template <class T>
T AInterpolatorCasteljau<T>::interpolateSegment(
    const std::vector<T>& keys,
    int segment, double t) const
{
    //T b0 = AInterpolatorCubic<T>::getControlPoint(segment * 4);
    //T b1 = AInterpolatorCubic<T>::getControlPoint(segment * 4 + 1);
    //T b2 = AInterpolatorCubic<T>::getControlPoint(segment * 4 + 2);
    //T b3 = AInterpolatorCubic<T>::getControlPoint(segment * 4 + 3);

    T xyz;
    return xyz;
}

template <class T>
void AInterpolatorCubic<T>::computeControlPoints(
    const std::vector<T>& keys)
{
    mCtrlPoints.clear();

    int totalPoints = keys.size();
    if (totalPoints <= 1) return;

    // If there are more than 1 interpolation point, set up the 2 end 
    // points to help determine the curve.
    // They lie on the tangent of the first and last interpolation points.
    for (int i = 1; i < (int) keys.size(); i++)
    {
        T b0, b1, b2, b3;

        
        mCtrlPoints.push_back(b0);
        mCtrlPoints.push_back(b1);
        mCtrlPoints.push_back(b2);
        mCtrlPoints.push_back(b3);
    }
}

template <class T>
T AInterpolatorHermite<T>::interpolateSegment(
    const std::vector<T>& keys,
    int segment, double t) const
{
    //T p0 = keys[segment];
    //T p1 = keys[segment + 1];
    //T q0 = AInterpolatorCubic<T>::getControlPoint(segment);
    //T q1 = AInterpolatorCubic<T>::getControlPoint(segment + 1);

    // TODO
    return T();
}


template <class T>
void AInterpolatorHermite<T>::computeControlPoints(
    const std::vector<T>& keys)
{
    AInterpolatorCubic<T>::clearControlPoints();
    if (keys.size() <= 1) return;

    // TODO
}

template <class T>
T AInterpolatorLinear<T>::interpolateSegment(
    const std::vector<T>& keys, int segment, double u) const
{
    //T key1 = keys[segment];
    //T key2 = keys[segment+1];
    // TODO
    return T();
}

template <class T>
T AInterpolatorMatrix<T>::interpolateSegment(
    const std::vector<T>& keys,
    int segment, double t) const
{
    //T b0 = AInterpolatorCubic<T>::getControlPoint(segment * 4);
    //T b1 = AInterpolatorCubic<T>::getControlPoint(segment * 4 + 1);
    //T b2 = AInterpolatorCubic<T>::getControlPoint(segment * 4 + 2);
    //T b3 = AInterpolatorCubic<T>::getControlPoint(segment * 4 + 3);

    return T();
}

inline AQuaternion AInterpolatorSBezier::interpolateSegment(
    const std::vector<AQuaternion>& keys, int segment, double u) const
{
    //AQuaternion b0 = AInterpolatorCubic<AQuaternion>::getControlPoint(segment*4+0); 
    //AQuaternion b1 = AInterpolatorCubic<AQuaternion>::getControlPoint(segment*4+1); 
    //AQuaternion b2 = AInterpolatorCubic<AQuaternion>::getControlPoint(segment*4+2); 
    //AQuaternion b3 = AInterpolatorCubic<AQuaternion>::getControlPoint(segment*4+3); 

    // TODO
    AQuaternion result;
    return result; 
}

inline void AInterpolatorSBezier::computeControlPoints(
   const std::vector<AQuaternion>& keys)
{
    AInterpolatorCubic<AQuaternion>::clearControlPoints();
    // TODO
}

inline AQuaternion AInterpolatorSquad::interpolateSegment(
    const std::vector<AQuaternion>& keys, int segment, double u) const
{
    return AQuaternion();
}


#endif

