#ifndef AHermiteInterpolator_H_
#define AHermiteInterpolator_H_

#include <Eigen/Dense>
#include "AInterpolatorCubic.h"

template <class T>
class AInterpolatorHermite : public AInterpolatorCubic<T>
{
public:
    AInterpolatorHermite() : AInterpolatorCubic<T>() {}
    virtual AInterpolationType getType() const { return CUBIC_HERMITE; }

    virtual T interpolateSegment(
        const std::vector<T>& keys, int segment, double u) const;

    virtual void computeControlPoints(const std::vector<T>& keys);
};

#endif

