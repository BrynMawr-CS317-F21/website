#include "AQuaternion.h"
#include "AMatrix3.h"
#include "AVector3.h"

AQuaternion AQuaternion::Slerp(const AQuaternion& q0, const AQuaternion& q1, double t)
{
	// TODO
	return AQuaternion(1,0,0,0);
}

void AQuaternion::toAxisAngle (AVector3& axis, double& angleRad) const
{
	// TODO
}

void AQuaternion::fromAxisAngle (const AVector3& axis, double angleRad)
{
	// TODO
}

AMatrix3 AQuaternion::toMatrix () const
{
	// TODO
	return AMatrix3::Identity;
}

void AQuaternion::fromMatrix(const AMatrix3& rot)
{
	// TODO
}

