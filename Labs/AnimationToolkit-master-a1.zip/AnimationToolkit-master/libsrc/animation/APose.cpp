#include "APose.h"

APose::APose() {}
APose::~APose() {}

APose::APose(const APose& p)
{
    assert(jointRots.size() == 0);
    rootPos = p.rootPos;
    for (unsigned int i = 0; i < p.jointRots.size(); i++)
    {
        jointRots.push_back(p.jointRots[i]);
    }
}

APose& APose::operator = (const APose& p)
{
    if (this == &p)
    {
        return *this;
    }

    jointRots.clear();
    rootPos = p.rootPos;
    for (unsigned int i = 0; i < p.jointRots.size(); i++)
    {
        jointRots.push_back(p.jointRots[i]);
    }
    return *this;
}

APose operator - (const APose& v)
{
    APose p;
    p.rootPos = -v.rootPos;
    for (unsigned int i = 0; i < v.jointRots.size(); i++)
    {
        p.jointRots.push_back(v.jointRots[i].inverse());
    }
    return p;
}

APose operator + (const APose& a, const APose& b)
{
    APose p;
    p.rootPos = a.rootPos + b.rootPos;
    for (unsigned int i = 0; i < a.jointRots.size(); i++)
    {
        AQuaternion q = b.jointRots[i] * a.jointRots[i];
        p.jointRots.push_back(q);
    }
    return p;
}

APose operator - (const APose& a, const APose& b)
{
    APose p;
    p.rootPos = a.rootPos - b.rootPos;
    for (unsigned int i = 0; i < a.jointRots.size(); i++)
    {
        AQuaternion q = b.jointRots[i] * a.jointRots[i].inverse();
        p.jointRots.push_back(q);
    }
    return p;
}

APose operator * (const APose& a, double d)
{
    APose p;
    p.rootPos = d * a.rootPos;
    for (unsigned int i = 0; i < a.jointRots.size(); i++)
    {
        AQuaternion q = a.jointRots[i];
        p.jointRots.push_back(q);
    }
    return p;
}

APose operator * (double d, const APose& a)
{
    APose p;
    p.rootPos = d * a.rootPos;
    for (unsigned int i = 0; i < a.jointRots.size(); i++)
    {
        AQuaternion q = a.jointRots[i];
        p.jointRots.push_back(q);
    }
    return p;
}

APose operator / (const APose& a, double d)
{
    APose p;
    p.rootPos = a.rootPos / d;
    for (unsigned int i = 0; i < a.jointRots.size(); i++)
    {
        AQuaternion q = a.jointRots[i];
        p.jointRots.push_back(q);
    }
    return p;
}

bool operator == (const APose& a, const APose& b)
{
    bool result = (a.rootPos == b.rootPos);
    for (unsigned int i = 0; result && i < a.jointRots.size(); i++)
    {
        result = result && (a.jointRots[i] == b.jointRots[i]);
    }
    return result;
}

bool operator != (const APose& a, const APose& b)
{
    return !operator==(a,b);
}

std::istream& operator>>(std::istream& s, APose& v)
{
    s >> v.rootPos; // TODO: Test this function

    v.jointRots.clear();
    for (unsigned int i = 0; i < v.jointRots.size(); i++)
    {
        AQuaternion q;
        s >> q;
        v.jointRots.push_back(q);
    }
    return s;
}

std::ostream& operator<<(std::ostream& s, const APose& v)
{
    s << "**************" << std::endl;
    s << v.rootPos << std::endl; 
    for (unsigned int i = 0; i < v.jointRots.size(); i++)
    {
        s << v.jointRots[i] << std::endl;
    }
    return s;
}

