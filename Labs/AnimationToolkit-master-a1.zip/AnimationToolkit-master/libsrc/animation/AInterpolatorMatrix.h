#ifndef AMatrixInterpolator_H_
#define AMatrixInterpolator_H_

#include "AInterpolatorCubic.h"
#include <Eigen/Dense>

template <class T>
class AInterpolatorMatrix : public AInterpolatorCubic<T>
{
public:
    AInterpolatorMatrix() : AInterpolatorCubic<T>() {}
    virtual AInterpolationType getType() const { return CUBIC_MATRIX; }

    virtual T interpolateSegment(
        const std::vector<T>& keys, int segment, double u) const;
};

#endif

