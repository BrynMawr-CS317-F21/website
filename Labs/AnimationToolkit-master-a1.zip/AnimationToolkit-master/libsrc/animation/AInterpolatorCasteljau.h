#ifndef ACasteljauInterpolator_H_
#define ACasteljauInterpolator_H_

#include "AInterpolatorCubic.h"

template <class T>
class AInterpolatorCasteljau : public AInterpolatorCubic<T>
{
public:
    AInterpolatorCasteljau() : AInterpolatorCubic<T>() {}
    virtual AInterpolationType getType() const { return CUBIC_CASTELJAU; }

    virtual T interpolateSegment(
        const std::vector<T>& keys, int segment, double u) const;
};

#endif

