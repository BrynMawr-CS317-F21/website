#ifndef ASBezierInterpolator_H_
#define ASBezierInterpolator_H_

#include "AInterpolatorCubic.h"
#include "AQuaternion.h"

class AInterpolatorSBezier : public AInterpolatorCubic<AQuaternion>
{
public:
    AInterpolatorSBezier() : AInterpolatorCubic<AQuaternion>() {}
    virtual AInterpolationType getType() const { return CUBIC_SBEZIER; }
    AQuaternion interpolateSegment( const std::vector<AQuaternion>& keys, 
        int segment, double u) const;
    void computeControlPoints( const std::vector<AQuaternion>& keys);
};

#endif
