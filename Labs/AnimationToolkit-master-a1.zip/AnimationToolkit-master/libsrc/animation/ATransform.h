#ifndef ATransform_H_
#define ATransform_H_

#include "AQuaternion.h"
#include "AVector3.h"

class ATransform
{
public:
    ATransform();
    ATransform(const AQuaternion& rotation, const AVector3& translation);
    ATransform(const ATransform& transform);
    ATransform& operator = (const ATransform& source); 

    ATransform inverse() const;
    void writeToGLMatrix(float* m);	
    void readFromGLMatrix(float* m);
    AVector3 transformPoint(const AVector3& pos) const;
    AVector3 transformVector(const AVector3& dir) const;

    friend ATransform operator * (const ATransform& a, const ATransform& b);// m1 * m2
    friend AVector3 operator * (const ATransform& a, const AVector3& v);	 
    friend std::ostream& operator << (std::ostream& s, const ATransform& v);

    static ATransform Identity;

public:
    AQuaternion rotation;
    AVector3 translation;
};
#endif

