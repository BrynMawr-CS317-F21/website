#ifndef ABernsteinInterpolator_H_
#define ABernsteinInterpolator_H_

#include "AInterpolatorCubic.h"

template <class T>
class AInterpolatorBernstein : public AInterpolatorCubic<T>
{
public:
    AInterpolatorBernstein() : AInterpolatorCubic<T>() {}
    virtual AInterpolationType getType() const { return CUBIC_BERNSTEIN; }
    virtual T interpolateSegment(
        const std::vector<T>& keys, int segment, double u) const;
};

#endif
