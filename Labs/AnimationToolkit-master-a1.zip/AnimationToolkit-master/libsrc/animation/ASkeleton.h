#ifndef ASkeleton_H_
#define ASkeleton_H_

#include "AJoint.h"
#include <vector>

class ASkeleton
{
public:
    ASkeleton();
    ASkeleton(const ASkeleton& skeleton); // Deep copy
    virtual ASkeleton& operator=(const ASkeleton& orig); // Deep copy

    virtual ~ASkeleton();
    virtual void fk();
    virtual void clear();

    AJoint* getByName(const std::string& name) const;
    AJoint* getByID(int id) const;
    AJoint* getRoot() const;

    void addJoint(AJoint* joint, bool isRoot = false);
    void deleteJoint(const std::string& name);

    int getNumJoints() const { return (int) mJoints.size(); }

protected:
    std::vector<AJoint*> mJoints;
    AJoint* mRoot;
};

typedef ASkeleton AAnimatableHierarchy;

#endif
