#ifndef ALinearInterpolator_H_
#define ALinearInterpolator_H_

#include "AInterpolator.h"
#include "AQuaternion.h"

template <class T>
class AInterpolatorLinear : public AInterpolator<T>
{
public:
    AInterpolatorLinear() : AInterpolator<T>() {}
    virtual bool hasControlPoints() const { return false; }
    virtual AInterpolationType getType() const { return LINEAR; }

    virtual T interpolateSegment(
        const std::vector<T>& keys, int segment, double u) const;
};


template <>
inline AQuaternion AInterpolatorLinear<AQuaternion>::interpolateSegment(
    const std::vector<AQuaternion>& keys, int segment, double u) const
{
    AQuaternion key1 = keys[segment];
    AQuaternion key2 = keys[segment+1];
    return AQuaternion::Slerp(key1, key2, u);
}

#endif

